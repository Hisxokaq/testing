const checkSpam = require('./func/checkSpam')

module.exports = {
    checkSpam
}